
public class OfferOrder extends Order
{
	
	public OfferOrder(String ID, double price, int volume)
	{
		super(ID, price, volume);
	}
	
}
