
public class BidOrder extends Order
{
	
	public BidOrder(String ID, double price, int volume)
	{
		super(ID, price, volume);
	}
	
}
