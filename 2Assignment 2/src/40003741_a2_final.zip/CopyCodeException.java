
public class CopyCodeException extends Exception
{
	public CopyCodeException()
	{
	}
	
	public CopyCodeException(String msg)
	{
		super(msg);
	}
}
